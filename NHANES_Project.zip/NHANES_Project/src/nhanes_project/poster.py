"""Populate the course's PurpleSidebar PowerPoint template and export its single page."""

from copy import deepcopy
from io import BytesIO
from pathlib import Path
import shutil
import subprocess
from tempfile import TemporaryDirectory
from xml.etree import ElementTree as ET
from xml.dom.minidom import parseString
from zipfile import ZIP_DEFLATED, ZipFile

import xlsxwriter

from .figures import label_itemset


TEMPLATE = (Path("AIAA3111_Poster_Templates_80x100cm") /
            "AIAA3111_Poster_Template_A_PurpleSidebar.pptx")
AUTHOR_LINE = "Yanzhe Xie (50013227)   ·   Ye Guo (50013485)   ·   Che Feng (50013502)"
NS = {
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "p": "http://schemas.openxmlformats.org/presentationml/2006/main",
    "c": "http://schemas.openxmlformats.org/drawingml/2006/chart",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
}
for prefix, uri in NS.items():
    ET.register_namespace(prefix, uri)

PURPLE = "671A86"
INK = "2A2A2A"
MUTED = "504858"
EMU_PER_CM = 360000


def element(parent, tag, **attrs):
    prefix, name = tag.split(":")
    return ET.SubElement(parent, f"{{{NS[prefix]}}}{name}", attrs)


def xml_bytes(root):
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def position(shape, x, y, w, h):
    transform = shape.find(".//a:xfrm", NS)
    if transform is None:
        transform = shape.find("p:xfrm", NS)
    transform.find("a:off", NS).attrib.update(x=str(round(x*EMU_PER_CM)), y=str(round(y*EMU_PER_CM)))
    transform.find("a:ext", NS).attrib.update(cx=str(round(w*EMU_PER_CM)), cy=str(round(h*EMU_PER_CM)))


class PosterSlide:
    def __init__(self, content):
        self.root = ET.fromstring(content)
        self.tree = self.root.find("p:cSld/p:spTree", NS)
        self.source = {}
        for shape in list(self.tree)[2:]:
            self.source[shape.find(".//p:cNvPr", NS).get("name")] = shape
            self.tree.remove(shape)
        self.next_id = 150

    def copy(self, source, name=None, bounds=None):
        shape = deepcopy(self.source[source])
        identity = shape.find(".//p:cNvPr", NS)
        identity.set("id", str(self.next_id))
        identity.set("name", name or source)
        self.next_id += 1
        if bounds:
            position(shape, *bounds)
        self.tree.append(shape)
        return shape

    def text(self, name, bounds, content, size, color=INK, bold=False, source="TextBox 55"):
        shape = self.copy(source, name, bounds)
        body = shape.find("p:txBody", NS)
        body.find("a:bodyPr", NS).set("anchor", "t")
        source_paragraph = body.find("a:p", NS)
        for original in body.findall("a:p", NS):
            body.remove(original)
        for line in content.split("\n"):
            paragraph = deepcopy(source_paragraph)
            paragraph.find(".//a:spcPct", NS).set("val", "102000")
            run = paragraph.find("a:r/a:rPr", NS)
            run.attrib.update(sz=str(round(size*100)), b=str(int(bold)))
            run.find(".//a:srgbClr", NS).set("val", color)
            paragraph.find("a:r/a:t", NS).text = line
            body.append(paragraph)

    def picture(self, name, relationship, bounds):
        picture = self.copy("HKUST(GZ) Logo", name, bounds)
        picture.find(".//p:cNvPr", NS).set("descr", name)
        picture.find(".//a:blip", NS).set(f"{{{NS['r']}}}embed", relationship)

    def table(self, name, rows, x, y, widths, heights, size):
        shape = self.copy("Table 70", name, (x, y, sum(widths), sum(heights)))
        table = shape.find(".//a:tbl", NS)
        grid = table.find("a:tblGrid", NS)
        for extra in list(grid)[len(widths):]:
            grid.remove(extra)
        for col, width in zip(grid, widths, strict=True):
            col.set("w", str(round(width*EMU_PER_CM)))
        originals = table.findall("a:tr", NS)
        for row in originals:
            table.remove(row)
        for i, (values, height) in enumerate(zip(rows, heights, strict=True)):
            row = deepcopy(originals[0 if i == 0 else 1+(i-1)%2])
            row.set("h", str(round(height*EMU_PER_CM)))
            for extra in row.findall("a:tc", NS)[len(widths):]:
                row.remove(extra)
            for j, (cell, value) in enumerate(zip(row.findall("a:tc", NS), values, strict=True)):
                cell.find(".//a:pPr", NS).set("algn", "l" if j == 0 else "ctr")
                cell.find(".//a:rPr", NS).attrib.update(sz=str(round(size*100)), b=str(int(i == 0)))
                fill = cell.find("a:tcPr/a:solidFill/a:srgbClr", NS)
                fill.set("val", "E8DDF0" if i == 0 else ("F5EFF8" if i % 2 else "FAF8FC"))
                cell.find(".//a:t", NS).text = value
                cell.find("a:tcPr", NS).attrib.update(marL="135000", marR="60000")
            table.append(row)


def health_chart(health):
    """Use the same workbook for the editable series and the chart's cached values."""
    buffer = BytesIO()
    with xlsxwriter.Workbook(buffer, {"in_memory": True}) as workbook:
        sheet = workbook.add_worksheet("Health")
        sheet.write_row(0, 0, ["Rule and group sizes", "All items present", "At least one absent"])
        percent = workbook.add_format({"num_format": "0.0%"})
        for i, row in enumerate(health.itertuples(), 1):
            sheet.write(i, 0, f"R{row.rank}\n{row.present_n}/{row.absent_n}")
            sheet.write_number(i, 1, row.present_proportion, percent)
            sheet.write_number(i, 2, row.absent_proportion, percent)
        chart = workbook.add_chart({"type": "column"})
        for col, color in [(1, PURPLE), (2, "C3A4D3")]:
            chart.add_series({
                "name": ["Health", 0, col], "categories": ["Health", 1, 0, len(health), 0],
                "values": ["Health", 1, col, len(health), col], "fill": {"color": "#" + color},
                "border": {"none": True}, "gap": 50,
            })
        font = {"name": "Arial", "size": 18, "color": "#" + MUTED}
        chart.set_x_axis({"num_font": font, "line": {"color": "#8494A2"}, "major_tick_mark": "none"})
        chart.set_y_axis({"min": 0, "num_format": "0%", "num_font": font,
                          "major_unit": .10, "major_tick_mark": "none", "line": {"none": True},
                          "major_gridlines": {"visible": True, "line": {"color": "#DCE3E8"}}})
        chart.set_legend({"position": "bottom", "font": font})
        chart.set_chartarea({"border": {"none": True}, "fill": {"color": "#FFFFFF"}})
        chart.set_size({"width": 1230, "height": 550})
        sheet.insert_chart("E2", chart)
    with ZipFile(buffer) as book:
        chart_xml = ET.fromstring(book.read("xl/charts/chart1.xml"))
    chart_xml.remove(chart_xml.find("c:printSettings", NS))
    external = element(chart_xml, "c:externalData", **{f"{{{NS['r']}}}id": "rId1"})
    element(external, "c:autoUpdate", val="0")
    return xml_bytes(chart_xml), buffer.getvalue()


def build_slide(slide, r, authors):
    n, settings = r.n, r.settings["mining"]
    lead = r.candidates.iloc[0]
    health = r.health.set_index("rank").loc[lead["rank"]]
    weighted = r.weighted.loc[r.weighted["rank"].eq(lead["rank"]) &
                              r.weighted.metric.eq("itemset_prevalence")].iloc[0]
    for name in slide.source:
        number = name.split()[-1]
        if (name == "HKUST(GZ) Logo" or number.isdigit() and
                (int(number) <= 26 or int(number) in
                 {31, 32, 33, 35, 36, 50, 51, 53, 54, 80, 81, 83})):
            slide.copy(name)

    slide.text("Title", (3, 8.55, 59, 8), "Which metabolic abnormalities\noccur together?",
               81, bold=True, source="TextBox 27")
    slide.text("Authors", (3, 16.6, 59, 1.95), authors, 29, source="TextBox 27")
    slide.text("Subtitle", (3, 18.65, 59, 1.85), "Association rules and self-rated health in NHANES 2017–2018",
               28, source="TextBox 27")
    slide.text("Course", (63, 11.6, 15, 5), "AIAA 3111\nData Mining", 40, PURPLE, True, source="TextBox 27")

    slide.text("Research question", (2.6, 25, 22.4, 4.2),
               "Which metabolic findings co-occur, and how do adults with those findings rate their health?", 32, bold=True)
    cohort = [("Cohort step", "Participants"),
              ("Seven files linked", f"{n['merged_demographics']:,}"),
              ("Examined, age 20+", f"{n['adult_mec']:,}"),
              ("All five measures", f"{n['adult_mec_complete_items']:,}"),
              ("Discovery / holdout", f"{n['discovery']:,} / {n['validation']:,}")]
    slide.table("Cohort flow", cohort, 2.6, 30.1, [13.3, 9.3], [1.75]*5, 25)
    slide.text("Indicators", (2.6, 39.8, 22.4, 5.7),
               "We flagged central obesity, elevated blood pressure (BP), elevated HbA1c, low HDL and high total cholesterol. Adults with zero flags counted toward support.", 27)

    slide.text("Mining criteria", (2.6, 50, 22.4, 5.8),
               f"We randomly split participants. Apriori and FP-Growth mined sets of up to {settings['max_itemset_size']} items. "
               f"Rules needed ≥{settings['min_support']:.0%} support and ≥{settings['min_confidence']:.0%} confidence.", 29)
    slide.text("Benchmark heading", (2.6, 56.3, 22.4, 1.6), "Median mining time (ms)", 31, PURPLE, True)
    timings = [("Adults", "Apriori", "FP-Growth")]
    for size, group in r.benchmark.groupby("n", sort=True):
        by_name = group.set_index("algorithm")
        timings.append((f"{size:,}", f"{by_name.loc['Apriori', 'median_ms']:.3f}",
                        f"{by_name.loc['FP-Growth', 'median_ms']:.3f}"))
    slide.table("Algorithm benchmark", timings, 2.6, 58.4, [4.3, 9.1, 9.2], [1.7]*len(timings), 23)
    slide.text("Weighted heading", (2.6, 76.1, 22.4, 1.7), "Population estimate", 31, PURPLE, True)
    slide.text("Weighted prevalence", (2.6, 78.1, 22.4, 5.0),
               f"Among adults with complete measures, the survey-weighted prevalence of central obesity with elevated HbA1c "
               f"was {weighted.proportion:.1%} (95% CI {weighted.ci_low:.1%}–{weighted.ci_high:.1%}).", 28)
    slide.text("Limits", (2.6, 84.4, 22.4, 5.9),
               "Adults with both findings more often reported fair or poor health. The survey measured both at one time. "
               "Missing measurements may affect the prevalence estimate.", 27)

    slide.text("Discovery heading", (28.45, 24.75, 49.4, 2), "Central obesity and elevated HbA1c co-occurred most often", 34, bold=True)
    slide.picture("Discovery co-occurrence heatmap", "rIdHeatmap", (28.25, 27.1, 25.8, 25.8*5/7.8))
    slide.text("Leading support", (55.0, 27.5, 22.7, 3.5), f"{lead.support:.1%}", 71, PURPLE, True)
    slide.text("Discovery counts", (55, 31.4, 22.7, 5.3),
               f"of discovery adults had both findings ({int(lead.joint_n):,}/{int(lead.n):,}). Among adults with central obesity, "
               f"{lead.confidence:.1%} had elevated HbA1c.", 29)
    slide.text("Rule selection", (55, 37.5, 22.7, 5.6),
               f"The miners found {int(r.main_grid.itemsets)} frequent itemsets and {int(r.main_grid.rules)} rules. "
               "We selected five combinations by discovery leverage, breaking ties by joint count.", 28)

    slide.text("Rules heading", (28.45, 44.3, 49.6, 1.9),
               f"{int(r.holdout.passes_thresholds.sum())} of {len(r.holdout)} rules met both thresholds in the holdout", 34, bold=True)
    rules = [("Rule", "Lift, discovery", "Lift, holdout", "Leverage, discovery", "Leverage, holdout")]
    for row in r.holdout.itertuples():
        rules.append((f"R{row.rank}   {label_itemset(row.antecedent)} → {label_itemset(row.consequent)}",
                      f"{row.discovery_lift:.3f}", f"{row.lift:.3f}",
                      f"{100*row.discovery_leverage:+.2f}", f"{100*row.leverage:+.2f}"))
    slide.table("Replicated rules", rules, 28.45, 46.6, [22.1, 6.4, 6.3, 7.6, 7.3], [2.3]+[1.8]*len(r.holdout), 23)
    slide.text("Metric definitions", (28.45, 58.35, 49.6, 2.2),
               "Lift divides observed by expected co-occurrence under independence. Leverage subtracts expected from observed, in percentage points (pp).", 24)

    slide.text("Increment heading", (28.45, 61.25, 26.0, 1.6), "Adding a second condition", 31, PURPLE, True)
    increments = [("Rule", "Baseline", "Confidence Δ", "Support Δ")]
    for row in r.gains.itertuples():
        increments.append((f"R{row.rank}", label_itemset(row.baseline_antecedent),
                           f"{row.confidence_gain_pp:+.2f}", f"{row.support_change_pp:+.2f}"))
    slide.table("Increment over one condition", increments, 28.45, 63.3, [3.5, 8.2, 7.6, 6.4], [2.1, 1.7, 1.7], 22)
    slide.text("Increment note", (28.45, 69.25, 25.8, 3.4),
               "Holdout changes in pp versus the single condition with higher discovery confidence.", 25)
    strat = r.holdout.loc[r.holdout.antecedent.eq("elevated_bp") & r.holdout.consequent.eq("elevated_hba1c")]
    if not strat.empty:
        row = strat.iloc[0]
        slide.text("Stratification heading", (55.5, 61.25, 22.5, 1.65), "Age and sex composition", 30, PURPLE, True)
        slide.text("Stratification", (55.5, 63.3, 22.5, 3.9),
                   f"R{int(row['rank'])} lift was {row.lift:.3f} overall. Observed cases were {row.observed_to_expected:.3f}× "
                   "the count expected within age and sex groups.", 25)
    slide.text("Stability heading", (55.5, 66.95, 22.5, 1.45), "Stability and missing data", 28, PURPLE, True)
    slide.text("Stability", (55.5, 68.55, 22.5, 4.6),
               f"All {int(r.stability.reselection_rate.eq(1).sum())} patterns recurred in {int(r.stability.repetitions.iloc[0])} subsamples. "
               f"Using available measures for each set shifted prevalence by ≤{r.wide.difference_pp.abs().max():.2f} pp.", 25)

    slide.text("Health heading", (28.45, 73.3, 49.4, 1.9), "Fair or poor self-rated health in the holdout", 34, bold=True)
    slide.text("Health comparison", (28.45, 75.3, 49.6, 2.4),
               f"Among {n['validation_valid_health']:,} respondents, {health.present_proportion:.1%} with the leading pair "
               f"rated their health fair or poor versus {health.absent_proportion:.1%} of the remaining adults.", 27)
    slide.copy("Chart 48", "Fair or poor health by rule membership", (28.45, 78.1, 22.0, 12.3))
    comparisons = [("Rule", "Present / other", "Gap (pp)", "Adj. OR (95% CI)")]
    for _, row in r.health.sort_values("rank").iterrows():
        comparisons.append((f"R{int(row['rank'])}", f"{row.present_proportion:.1%} / {row.absent_proportion:.1%}",
                            f"{row.difference_pp:+.1f}",
                            f"{row['or']:.2f} ({row.or_ci_low:.2f}–{row.or_ci_high:.2f})"))
    slide.table("Health outcomes", comparisons, 50.9, 78.3, [2.8, 8.3, 5.0, 10.9], [1.55]*len(comparisons), 22)
    slide.text("Model note", (51.3, 88.1, 26.5, 2.8),
               f"Odds ratios adjust for age and sex. Intervals account for clustering in {int(health.model_clusters)} survey PSUs.", 23)
    slide.text("References", (16.4, 91.9, 61.8, 5.1),
               "CDC / NCHS. National Health and Nutrition Examination Survey, 2017–2018.\n"
               "Agrawal & Srikant. Fast Algorithms for Mining Association Rules (1994).\n"
               "Han, Pei & Yin. Mining Frequent Patterns without Candidate Generation (2000).", 26)


def draw_poster(results, path, authors=AUTHOR_LINE):
    converter = shutil.which("libreoffice") or shutil.which("soffice")
    if not converter:
        raise RuntimeError("Install LibreOffice Impress to export the editable poster to PDF.")
    path.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(dir=path.parent) as tmp:
        work = Path(tmp).resolve()
        deck = work / path.with_suffix(".pptx").name
        with ZipFile(TEMPLATE) as source, ZipFile(deck, "w", ZIP_DEFLATED) as target:
            slide = PosterSlide(source.read("ppt/slides/slide1.xml"))
            build_slide(slide, results, authors)
            chart, workbook = health_chart(results.health.sort_values("rank"))
            props = parseString(source.read("docProps/core.xml"))
            for tag, value in {"dc:title": "Which metabolic abnormalities occur together?",
                               "dc:creator": authors, "dc:description": "AIAA 3111 course project poster",
                               "cp:lastModifiedBy": authors}.items():
                node = props.getElementsByTagName(tag)[0]
                if node.firstChild:
                    node.removeChild(node.firstChild)
                node.appendChild(props.createTextNode(value))
            rels = parseString(source.read("_rels/.rels"))
            for rel in list(rels.getElementsByTagName("Relationship")):
                if rel.getAttribute("Type").endswith("/thumbnail"):
                    rel.parentNode.removeChild(rel)
            updates = {"ppt/slides/slide1.xml": xml_bytes(slide.root), "ppt/charts/chart1.xml": chart,
                       "docProps/core.xml": props.toxml(encoding="utf-8"), "_rels/.rels": rels.toxml(encoding="utf-8"),
                       "ppt/embeddings/Microsoft_Excel_Sheet1.xlsx": workbook}
            slide_rels_path = "ppt/slides/_rels/slide1.xml.rels"
            slide_rels = ET.fromstring(source.read(slide_rels_path))
            ET.SubElement(slide_rels, slide_rels[0].tag, Id="rIdHeatmap",
                          Type=NS["r"] + "/image", Target="../media/cooccurrence.png")
            updates[slide_rels_path] = xml_bytes(slide_rels)
            target.write(results.figure("cooccurrence_heatmap"), "ppt/media/cooccurrence.png")
            for item in source.infolist():
                if item.filename != "docProps/thumbnail.jpeg":
                    target.writestr(item, updates[item.filename] if item.filename in updates else source.read(item))
        subprocess.run([converter, "-env:UserInstallation=" + (work / "lo").as_uri(), "--headless",
                        "--convert-to", "pdf:impress_pdf_Export", "--outdir", str(work), str(deck)],
                       check=True, capture_output=True, timeout=120)
        rendered = deck.with_suffix(".pdf")
        if not rendered.is_file():
            raise RuntimeError("LibreOffice did not export the poster.")
        deck.replace(path.with_suffix(".pptx"))
        rendered.replace(path)
